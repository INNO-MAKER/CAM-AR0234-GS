# AR0234 — usage

## Overlay options (`dtoverlay=ar0234,<opts>`)

| option | description | default |
|---|---|---|
| `cam0` | use cam0 connector instead of cam1 | cam1 |
| `4lane` | 4-lane MIPI CSI-2 (confirm the port wires 4 lanes) | 2 lanes |
| `mono` | force monochrome (Y10) | off (auto by chip id) |
| `link-frequency=<Hz>` | `450000000` (10-bit) or `360000000` (8-bit) | 450 MHz |
| `external-trigger` | pulsed / automatic trigger via TRIG pin | off |
| `sync-sink` | multi-sensor sync to TRIG | off |
| `flash`, `flash-lead=<n>`, `flash-lag=<n>` | FLASH output + timing | off |
| `always-on` | keep regulator powered | off |
| `rotation=<0\|180>`, `orientation=<n>` | orientation | 180 / 2 |

Examples:
```ini
dtoverlay=ar0234,cam0,4lane                       # colour, 4-lane, cam0
dtoverlay=ar0234,cam0,4lane,mono                  # mono module
dtoverlay=ar0234,cam0,4lane,mono,external-trigger,flash
dtoverlay=ar0234,link-frequency=360000000         # 8-bit output
```

## Verify

```bash
dmesg | grep ar0234                    # chip id, link, lanes
rpicam-hello --list-cameras            # colour: "10-bit GRBG"  |  mono: "10-bit MONO"
media-ctl -d /dev/media1 -p | grep -A2 ar0234    # SGRBG10 (colour) or Y10 (mono)
```

## Capture (needs Package 2 libcamera installed)

```bash
rpicam-hello -t 0                                             # live preview
rpicam-still -o still.jpg --width 1920 --height 1200          # full-res still
rpicam-vid  -t 5000 -o clip.h264                             # video
rpicam-still --raw -o frame.dng                              # raw DNG
```

## High frame rate

The on-screen preview is display-limited (often ~30 fps) and AGC lengthens exposure in low light,
which caps the effective rate. To actually run the sensor fast, pin the mode + framerate + a short
shutter:

```bash
# full resolution 120 fps (4-lane, 10-bit)
rpicam-vid -t 5000 --mode 1920:1200:10 --framerate 120 --shutter 4000 --gain 4.0 \
           --codec yuv420 -o fast.yuv --nopreview

# 960x600 binned, up to 237 fps
rpicam-vid -t 5000 --mode 960:600:10 --framerate 237 --shutter 2000 --gain 4.0 \
           --codec yuv420 -o fast.yuv --nopreview
```

Notes:
- `--nopreview` removes the display-refresh cap; measure fps from the frame count / duration.
- A short `--shutter` is required — exposure time must be ≤ `1/framerate`.
- Provide enough light (or raise `--gain`) since exposure is very short at high fps.

## Monochrome

For a mono module use `,mono` (see README / TECHNICAL). Output is true greyscale (Y10, no demosaic);
libcamera auto-selects `ar0234_mono.json`. Without `,mono` a mono sensor renders with false colour.

## External trigger & FLASH

See `docs/trigger_flash_guide.md` for wiring (1.8 V TRIG/FLASH), the pulsed/automatic/sync-sink
modes, the exposure constraint, max trigger frequency, and the test procedure.
