#!/bin/bash
# trigger_test.sh - quick AR0234 external-trigger sanity check.
# Assumes the overlay was set with ,external-trigger (or sync-sink) and rebooted,
# and a 1.8V pulse train is applied to the TRIG pin.
set -euo pipefail

DUR="${DUR:-5000}"          # ms
SHUTTER="${SHUTTER:-10000}" # us (fixed exposure, AGC off)
GAIN="${GAIN:-2.0}"
FPS="${FPS:-30}"            # set to your TRIG pulse rate
OUT="${OUT:-trig_test.h264}"

echo "=== AR0234 trigger test ==="
echo "trigger_mode = $(cat /sys/module/ar0234/parameters/trigger_mode 2>/dev/null || echo '?')"
dmesg | grep -i ar0234 | tail -3 || true
echo ""
echo "Capturing ${DUR}ms at fixed shutter=${SHUTTER}us gain=${GAIN}, expecting ~${FPS} fps from TRIG..."
rpicam-vid -t "$DUR" --shutter "$SHUTTER" --gain "$GAIN" --framerate "$FPS" \
           --nopreview -o "$OUT"

FRAMES=$(( DUR * FPS / 1000 ))
echo ""
echo "Saved: $OUT"
echo "Expected ~${FRAMES} frames if TRIG runs at ${FPS} Hz for ${DUR}ms."
echo "Inspect: ffprobe -count_frames -show_entries stream=nb_read_frames $OUT 2>/dev/null | grep nb_read_frames"
