# Changelog

## v1.0.0 (2026-07-07)

- Initial AR0234 source release for Raspberry Pi (Pi 5 verified, kernel 6.12.47+rpt-rpi-2712).
- Colour (SGRBG10) and monochrome (Y10) support.
- Added `mono` overlay param / `monochrome` DT property to force Y10 for mono modules that report the
  colour chip id (`0x0A56`); fixes false-colour rendering of mono sensors.
- External trigger (pulsed / automatic / sync-sink) and FLASH output documented (see
  `docs/trigger_flash_guide.md`).
- `install.sh` with stale-module handling, load-path self-verify, append-only `config.txt`,
  no auto-reboot.

### Verified on hardware
- Mono module, 4-lane, cam0, 1920×1200: probe, streaming, true greyscale (Y10, `ar0234_mono.json`).

### Pending hardware verification
- External trigger timing / FLASH lead-lag measurements (see `docs/trigger_flash_guide.md` §5).
