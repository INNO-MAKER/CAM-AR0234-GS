# AR0234 External Trigger & FLASH — configuration and test

AR0234 external trigger is a **sensor-hardware** function driven by the `TRIG` pin
(**1.8 V logic**), not Raspberry Pi GPIO. The Pi side only selects the trigger mode and captures
with a fixed exposure/gain. FLASH is a sensor output pin (**1.8 V**) that goes HIGH during exposure.

> Wiring: `TRIG` / `FLASH` are on the camera module connector, at **1.8 V** logic. Level-shift any
> 3.3 V/5 V source before connecting.

## 1. Trigger modes

| overlay option | mode | behaviour |
|---|---|---|
| `external-trigger` (pulsed) | standby until pulse | each `TRIG` high pulse (min 125 ns) captures one frame; fps = pulse rate |
| `external-trigger` (automatic) | gated continuous | `TRIG` held high → continuous frames at configured fps |
| `sync-sink` | pipelined sync | streams continuously, frame timing locked to `TRIG`; exposure/readout overlap (higher fps). Trigger period must be ≥ frame length |

### Enable via overlay (per-sensor, recommended)

In `/boot/firmware/config.txt`, then reboot:

```ini
camera_auto_detect=0
dtoverlay=ar0234,cam0,4lane,external-trigger        # colour
dtoverlay=ar0234,cam0,4lane,mono,external-trigger   # mono module
# or
dtoverlay=ar0234,cam0,4lane,sync-sink
```

### Enable via module param (runtime, global to all AR0234)

```bash
# 0=off, 1=external-trigger, 2=sync-sink
echo 1 | sudo tee /sys/module/ar0234/parameters/trigger_mode
```

Device-tree setting takes precedence over the module param. The module param applies to every
AR0234 in a multi-camera setup.

## 2. Capture under external trigger

Always pin shutter + gain (AGC goes unstable under trigger):

```bash
rpicam-hello -t 0 --shutter 10000 --gain 2.0
# still on each trigger:
rpicam-still --shutter 10000 --gain 2.0 -o shot.jpg
```

**Exposure constraint (pulsed):**

```
exposure_time < trigger_period - (1 / max_fps) - ~1.6 ms
```

Example: full-res 4-lane 10-bit (max 120 fps) triggered at 30 Hz →
`1/30 - 1/120 - 1.6 ms ≈ 23.7 ms` max exposure.

**Max pulsed trigger frequency:**

| Resolution | 4-lane | 2-lane |
|---|---|---|
| 1920×1200 | 60 Hz | 30 Hz |
| 960×600 (2×2) | 120 Hz | 60 Hz |

## 3. FLASH output

```ini
dtoverlay=ar0234,cam0,4lane,flash                 # FLASH HIGH during exposure
dtoverlay=ar0234,cam0,4lane,flash,flash-lead=10   # start ~34 µs before exposure (4-lane)
dtoverlay=ar0234,cam0,4lane,flash,flash-lag=10    # start ~34 µs after exposure begins
```

`flash-lead`/`flash-lag` range 0–127, each unit ≈ **3.4 µs** (4-lane) / **6.8 µs** (2-lane).

## 4. Test procedure

1. Set the overlay (e.g. `...,mono,external-trigger,flash`) in `config.txt`, reboot.
2. Confirm mode:
   ```bash
   cat /sys/module/ar0234/parameters/trigger_mode
   dmesg | grep -i ar0234
   ```
3. Feed a 1.8 V pulse train into `TRIG` (function generator / MCU), e.g. 30 Hz, 50 % duty.
4. Capture with fixed exposure and count frames:
   ```bash
   rpicam-vid -t 5000 --shutter 10000 --gain 2.0 --framerate 30 -o trig.h264
   rpicam-hello -t 0 --shutter 10000 --gain 2.0        # live check
   ```
5. Scope `FLASH` vs `TRIG` to confirm timing and lead/lag.

## 5. Measured results

_(to be filled in after hardware test)_

| item | expected | measured |
|---|---|---|
| pulsed 30 Hz → frame rate | 30 fps | _TBD_ |
| frame drops over 5 s | 0 | _TBD_ |
| FLASH high during exposure | yes | _TBD_ |
| flash-lead=10 offset | ~34 µs | _TBD_ |
