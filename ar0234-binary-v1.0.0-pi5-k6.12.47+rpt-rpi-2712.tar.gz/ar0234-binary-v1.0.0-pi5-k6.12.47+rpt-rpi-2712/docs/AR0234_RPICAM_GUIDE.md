# AR0234 — rpicam Command Guide (Raspberry Pi 5)

Everyday `rpicam-*` usage for the AR0234 global-shutter camera. Assumes Package 1 (driver) +
Package 2 (libcamera / rpicam-apps) are installed and the camera enumerates:

```bash
rpicam-hello --list-cameras     # mono module -> "...10-bit MONO"; colour -> "...10-bit GRBG"
```

## Modes & frame rates (this module: mono, R10_CSI2P)

| Mode (`--mode W:H:bits`) | Max fps | Crop |
|---|---|---|
| `960:600:10`   | 236.85 | 2×2 binned, full FoV |
| `1280:720:10`  | 198.49 | centre crop |
| `1920:1080:10` | 133.58 | centre crop |
| `1920:1200:10` | 120.45 | full sensor (native) |

Global shutter — every pixel integrates at once, so there is no rolling-shutter skew on fast motion.

---

## 3. Preview (window vs resolution — they are separate!)

```bash
rpicam-hello -t 0                            # default windowed preview
rpicam-hello -t 0 -f                         # FULLSCREEN preview
rpicam-hello -t 0 -p 0,0,1280,800            # preview window at x,y,w,h
rpicam-hello -t 0 -n                         # no preview (headless)
```

Capture resolution and the preview window are independent:

```bash
# Same small window, different CAPTURE resolutions (window does NOT change):
rpicam-hello -t 0 -p 100,100,640,480 --mode 960:600:10
rpicam-hello -t 0 -p 100,100,640,480 --mode 1920:1200:10

# Same CAPTURE resolution, different preview WINDOWS:
rpicam-hello -t 0 --mode 1920:1200:10 -f
rpicam-hello -t 0 --mode 1920:1200:10 -p 0,0,1280,800

# Preview STREAM resolution (not the window): use viewfinder-*
rpicam-hello -t 0 --viewfinder-mode 1920:1200:10 -f
rpicam-hello -t 0 --viewfinder-width 1280 --viewfinder-height 720
```

Rule of thumb: `--width/--height/--mode` -> **capture** (saved/encoded frames);
`-p / -f / -n` -> **preview window**; `--viewfinder-*` -> **preview stream** resolution.

---

## 4. Stills

```bash
rpicam-still -o img.jpg                                   # default
rpicam-still -o full.jpg --width 1920 --height 1200       # full resolution
rpicam-still --raw -o frame.dng                           # raw Y10 (mono) / Bayer (colour) DNG
rpicam-still -o m.jpg --shutter 5000 --gain 2.0           # fixed exposure/gain
rpicam-still -t 0 -o snap.jpg --keypress                  # capture on Enter
```

Mono module: white-balance (`--awbgains`) has no effect — there is no colour to balance.

---

## 5. Video

```bash
rpicam-vid -t 5000 -o clip.h264                          # 5 s H.264
rpicam-vid -t 5000 --width 1920 --height 1200 -o full.h264
rpicam-vid -t 5000 --codec mjpeg -o clip.mjpeg
rpicam-vid -t 0 --inline -o - | ...                      # continuous stream to stdout
```

---

## 6. High frame rate

Pick a binned/smaller mode, set `--framerate`, keep `--shutter` <= 1/framerate
(add light or raise `--gain`), and read the achieved rate with `--info-text "%fps"`.
Writing raw `yuv420` with `--nopreview` avoids the encoder/preview becoming the bottleneck.

```bash
# 1920x1200 native, 10-bit (up to ~120 fps)
rpicam-vid -t 5000 --mode 1920:1200:10 --framerate 120 --shutter 4000 --gain 4.0 \
           --codec yuv420 --nopreview --info-text "%fps" -o full.yuv

# 1280x720, 10-bit (up to ~198 fps)
rpicam-vid -t 5000 --mode 1280:720:10 --framerate 198 --shutter 3000 --gain 4.0 \
           --codec yuv420 --nopreview -o hs720.yuv

# 960x600 2x2 binned, 10-bit — highest rate (up to ~237 fps)
rpicam-vid -t 5000 --mode 960:600:10 --framerate 237 --shutter 2000 --gain 6.0 \
           --codec yuv420 --nopreview -o hs600.yuv
```

Note: the on-screen preview is capped near ~120 fps by the display; the sensor still delivers the
full rate to the encoder/file — use `--info-text "%fps"` or count frames to confirm.

---

## 7. Manual controls

```bash
rpicam-hello -t 0 --shutter 8000                  # exposure (us)
rpicam-hello -t 0 --gain 4.0                       # analogue+digital gain
rpicam-hello -t 0 --hflip --vflip                  # flip the image
rpicam-hello -t 0 --roi 0.25,0.25,0.5,0.5          # digital zoom (normalised x,y,w,h)
rpicam-hello -t 0 --framerate 60                   # cap frame rate
rpicam-hello -t 0 --awbgains 1.0,1.0               # fixed WB (colour module only)
```

Under external trigger, always pin `--shutter` and `--gain` (AGC goes unstable) — see
`trigger_flash_guide.md`.
