# AR0234 binary — install

## Requirements

- Raspberry Pi 5, kernel `6.12.47+rpt-rpi-2712` (aarch64). The installer checks vermagic and stops
  on mismatch.
- For `rpicam-*`/`libcamera`: the AR0234 libcamera package installed (CamHelper + tuning).

## Steps

```bash
tar xzf ar0234-binary-v1.0.0-pi5-k6.12.47+rpt-rpi-2712.tar.gz
cd ar0234-binary-v1.0.0-pi5-k6.12.47+rpt-rpi-2712
sudo ./driver/install.sh
sudo reboot
```

Select the overlay options for your module with `OVERLAY_OPTS` (default `cam0,4lane`):

```bash
OVERLAY_OPTS="cam0,4lane,mono"                  sudo ./driver/install.sh   # mono
OVERLAY_OPTS="cam0,4lane,external-trigger,flash" sudo ./driver/install.sh   # trigger + flash
OVERLAY_OPTS="cam1,2lane"                        sudo ./driver/install.sh   # cam1, 2-lane
```

The installer:
- refuses to install if the module vermagic ≠ running kernel;
- installs `ar0234.ko` to `/lib/modules/$(uname -r)/updates/dkms/` (highest priority) and backs up
  + clears any stale `ar0234.ko`/`ar0234.ko.xz` in both that dir and `kernel/drivers/media/i2c/`;
- self-verifies with `modinfo -F filename ar0234`;
- installs `ar0234.dtbo` to `/boot/firmware/overlays/`;
- appends `camera_auto_detect=0` + the `dtoverlay=ar0234,...` line to `config.txt`
  (backed up as `config.txt.bak.<timestamp>`), and does **not** reboot automatically.

## Verify (after reboot)

```bash
dmesg | grep ar0234
rpicam-hello --list-cameras            # colour: "10-bit GRBG"  |  mono: "10-bit MONO"
```

## Uninstall

```bash
sudo modprobe -r ar0234
sudo rm -f /lib/modules/$(uname -r)/updates/dkms/ar0234.ko
sudo depmod -a
# restore config.txt from the /boot/firmware/config.txt.bak.<timestamp> the installer made
```
