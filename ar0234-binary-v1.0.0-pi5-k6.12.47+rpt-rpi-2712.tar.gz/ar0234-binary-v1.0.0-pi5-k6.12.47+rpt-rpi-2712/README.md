# AR0234 camera driver — binary package v1.0.0

Prebuilt AR0234 kernel driver + device-tree overlay for **Raspberry Pi 5**,
kernel **6.12.47+rpt-rpi-2712** (aarch64).

- onsemi AR0234CS, 2.3 MP global shutter, colour + monochrome
- 2/4-lane MIPI CSI-2, 8/10-bit; 1920×1200@120 fps down to 960×600@237 fps (4-lane)
- External trigger (pulsed / automatic / sync-sink) and FLASH output

## Contents

```
driver/ar0234.ko       prebuilt kernel module (stripped)
driver/ar0234.dtbo     device-tree overlay
driver/install.sh      installer (module + overlay + config.txt)
docs/trigger_flash_guide.md
tools/trigger_test.sh
INSTALL.md  USAGE.md  CHANGELOG.md
```

## Install

```bash
sudo ./driver/install.sh                          # colour, cam0, 4-lane
OVERLAY_OPTS="cam0,4lane,mono" sudo ./driver/install.sh   # mono module
sudo reboot
```

See `INSTALL.md` for details, `USAGE.md` for capture / high frame rate,
`docs/trigger_flash_guide.md` for trigger & FLASH.

## Compatibility

This module targets kernel **6.12.47+rpt-rpi-2712** on Pi 5. The installer refuses to install on a
different kernel. If your kernel differs, contact your supplier for a matching build.

`rpicam-*` / `libcamera` also require the AR0234 libcamera build (CamHelper + tuning) — a separate
package.
