#!/bin/bash
# AR0234 driver - install prebuilt module + overlay.
# Installs to the highest-priority module path, backs up and clears stale shadows,
# self-verifies the load path, installs the overlay, appends config.txt. No auto-reboot.
set -euo pipefail
[ "$EUID" -eq 0 ] || { echo "Please run as root (sudo): sudo ./install.sh"; exit 1; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
KERNEL_REL="$(uname -r)"
TS="$(date +%Y%m%d-%H%M%S)"
OVERLAY_OPTS="${OVERLAY_OPTS:-cam0,4lane}"   # e.g. OVERLAY_OPTS="cam0,4lane,mono"

echo "=== Installing AR0234 driver (prebuilt) ==="
echo "Kernel: $KERNEL_REL   Overlay: dtoverlay=ar0234,$OVERLAY_OPTS"

# Kernel match check (vermagic)
VM="$(modinfo -F vermagic "$SCRIPT_DIR/ar0234.ko" 2>/dev/null | awk '{print $1}')"
if [ "$VM" != "$KERNEL_REL" ]; then
    echo "ERROR: module built for kernel '$VM' but running '$KERNEL_REL'."
    echo "This binary requires kernel $VM. Contact your supplier for a matching build."
    exit 1
fi

# 1. Module -> highest-priority path, clear stale .ko/.ko.xz shadows
echo "[1/3] Installing kernel module..."
modprobe -r ar0234 2>/dev/null || true
DEST="/lib/modules/$KERNEL_REL/updates/dkms"
KDEST="/lib/modules/$KERNEL_REL/kernel/drivers/media/i2c"
mkdir -p "$DEST"
for d in "$DEST" "$KDEST"; do
    [ -f "$d/ar0234.ko" ]    && mv "$d/ar0234.ko"    "$d/ar0234.ko.bak.$TS"
    [ -f "$d/ar0234.ko.xz" ] && mv "$d/ar0234.ko.xz" "$d/ar0234.ko.xz.bak.$TS"
done
cp "$SCRIPT_DIR/ar0234.ko" "$DEST/"
depmod -a
LOADED="$(modinfo -F filename ar0234 2>/dev/null || true)"
echo "  will load: $LOADED"
case "$LOADED" in
    */updates/dkms/ar0234.ko) echo "  OK" ;;
    *) echo "  ERROR: kernel would load a different module: $LOADED"; exit 1 ;;
esac

# 2. Overlay
echo "[2/3] Installing device-tree overlay..."
install -m 644 "$SCRIPT_DIR/ar0234.dtbo" /boot/firmware/overlays/ar0234.dtbo

# 3. config.txt (append-only, backed up)
echo "[3/3] Updating config.txt..."
CFG=/boot/firmware/config.txt; [ -f "$CFG" ] || CFG=/boot/config.txt
cp "$CFG" "$CFG.bak.$TS"
sed -i '/^dtoverlay=ar0234/d;/^camera_auto_detect=/d' "$CFG"
{
    echo ""
    echo "# AR0234 (installed $TS)"
    echo "camera_auto_detect=0"
    echo "dtoverlay=ar0234,$OVERLAY_OPTS"
} >> "$CFG"

echo ""
echo "OK. Reboot required (not done automatically): sudo reboot"
echo "After reboot: rpicam-hello --list-cameras   (also needs the libcamera package installed)"
