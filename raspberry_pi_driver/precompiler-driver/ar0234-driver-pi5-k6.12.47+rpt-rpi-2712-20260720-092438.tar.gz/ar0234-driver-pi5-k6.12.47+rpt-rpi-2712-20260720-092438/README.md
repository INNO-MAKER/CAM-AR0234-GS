# ar0234 driver + overlay

Exported from a running system. Kernel module and device-tree overlay only.

Kernel: **6.12.47+rpt-rpi-2712**    Variant: pi5
Built on: debian trixie (13)    Date: 20260720-092438

## Contents
- `driver/ar0234.ko` -- vermagic `6.12.47+rpt-rpi-2712`
- `driver/ar0234.dtbo`
- `install.sh`

## Install
```bash
sudo ./install.sh
sudo reboot
```

`install.sh` refuses to run on any kernel other than `6.12.47+rpt-rpi-2712`.
It does **not** modify `config.txt` -- manage the `dtoverlay=` line yourself.

Overlay params available: `4lane always-on cam0 external-trigger flash flash-lag flash-lead link-frequency media-controller mono orientation rotation sync-sink `

## Scope
Kernel side only. libcamera/IPA is packaged separately; nothing here depends on
the target's libcamera version.
