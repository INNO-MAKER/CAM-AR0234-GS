# AR0234 — External Trigger & Strobe (FLASH) Manual

Complete guide for running the AR0234 global-shutter camera on Raspberry Pi under **external
hardware trigger** with a synchronized **strobe / FLASH** output. Applies to the AR0234 driver
(Package 1) + AR0234 libcamera build (Package 2).

---

## 1. Concept

- **External trigger** is a *sensor-hardware* function: an external signal on the `TRIG` pin drives
  frame capture. Raspberry Pi does **not** trigger over GPIO — it only selects the trigger mode and
  captures with fixed exposure/gain.
- **Strobe / FLASH** is a *sensor output*: the `FLASH` pin goes HIGH during exposure, to drive an
  external illuminator (LED / laser / strobe) perfectly aligned to the global-shutter exposure
  window.

Because AR0234 is **global shutter**, every pixel integrates simultaneously — ideal for
freeze-motion strobe imaging and multi-camera sync.

---

## 2. Wiring (read first)

| Pin | Direction | Level | Notes |
|---|---|---|---|
| `TRIG` | input to sensor | **1.8 V logic** | trigger pulse source (function gen / MCU / PLC) |
| `FLASH` | output from sensor | **1.8 V logic** | HIGH during exposure; drive illuminator via a level shifter / MOSFET |
| `GND` | — | — | common ground between Pi module, trigger source, and illuminator |

> ⚠️ **1.8 V logic.** Level-shift any 3.3 V / 5 V trigger source down to 1.8 V before wiring to
> `TRIG`, and shift `FLASH` up if your illuminator driver needs 3.3 V/5 V. A common ground is
> mandatory. Wrong levels = no trigger, or damage.

---

## 3. Trigger modes

| Mode | overlay option | Behaviour | Use case |
|---|---|---|---|
| **Pulsed** | `external-trigger` | sensor in standby; each `TRIG` high pulse (min 125 ns) → one frame; fps = pulse rate | precise single-shot capture, machine vision |
| **Automatic** | `external-trigger` | `TRIG` held HIGH → continuous frames at configured fps | gated continuous acquisition |
| **Sync-sink** | `sync-sink` | continuous stream, frame timing locked to `TRIG`; exposure/readout pipelined (higher fps). Trigger period ≥ frame length | multi-camera synchronization |

---

## 4. Configuration

### 4.1 Overlay (recommended — per sensor, survives reboot)

`/boot/firmware/config.txt`:

```ini
camera_auto_detect=0

# External trigger + strobe, colour module, 4-lane, cam0:
dtoverlay=ar0234,cam0,4lane,external-trigger,flash

# Mono module:
dtoverlay=ar0234,cam0,4lane,mono,external-trigger,flash

# Sync-sink (multi-camera) + strobe:
dtoverlay=ar0234,cam0,4lane,sync-sink,flash

# Strobe timing shift (see §6):
dtoverlay=ar0234,cam0,4lane,external-trigger,flash,flash-lead=10
```

Reboot after editing.

### 4.2 Module parameter (runtime, no reboot — global to all AR0234)

```bash
# 0=off, 1=external-trigger, 2=sync-sink
echo 1 | sudo tee /sys/module/ar0234/parameters/trigger_mode
```

DT setting takes precedence over the module parameter. In a multi-camera rig, use DT to configure
each sensor independently.

---

## 5. Capturing under trigger

**Always pin shutter and gain** — the AGC goes unstable under external trigger:

```bash
# live view
rpicam-hello -t 0 --shutter 10000 --gain 2.0

# record; --framerate = your TRIG pulse rate
rpicam-vid -t 5000 --shutter 10000 --gain 2.0 --framerate 30 -o trig.h264

# single still per trigger
rpicam-still --shutter 10000 --gain 2.0 -o shot.jpg
```

**Exposure constraint (pulsed):**

```
exposure_time  <  trigger_period − (1 / max_fps) − ~1.6 ms
```

`max_fps` = the mode's max frame rate; ~1.6 ms covers MIPI wake-up + sensor overhead.
Example: full-res 4-lane 10-bit (max 120 fps), triggered at 30 Hz →
`1/30 − 1/120 − 1.6 ms ≈ 23.7 ms` maximum exposure.

**Maximum pulsed trigger frequency:**

| Resolution | 4-lane | 2-lane |
|---|---|---|
| 1920×1200 (full) | 60 Hz | 30 Hz |
| 960×600 (2×2 bin) | 120 Hz | 60 Hz |

---

## 6. Strobe / FLASH output

Enable with `flash`. The `FLASH` pin is HIGH for the exposure window (longer by ~8 µs on 4-lane /
~16 µs on 2-lane due to sensor overhead). Shift the pulse relative to exposure:

| option | effect | range / unit |
|---|---|---|
| `flash-lead=<n>` | FLASH starts **before** exposure (extends flash time) | 0–127, ≈3.4 µs/unit (4-lane), ≈6.8 µs/unit (2-lane) |
| `flash-lag=<n>` | FLASH starts **after** exposure begins (shortens flash time) | same |

```ini
dtoverlay=ar0234,cam0,4lane,flash,flash-lead=10   # ~34 µs pre-lead (4-lane)
dtoverlay=ar0234,cam0,4lane,flash,flash-lag=10    # ~34 µs delay
```

Typical strobe use: `external-trigger,flash` — each trigger captures a frame and fires the strobe
for exactly the exposure window, freezing motion under short, bright illumination.

---

## 7. Worked examples

**A. Machine-vision single-shot, strobe-lit, mono, 30 Hz**

```ini
dtoverlay=ar0234,cam0,4lane,mono,external-trigger,flash
```
```bash
# TRIG = 30 Hz 1.8V pulses; strobe LED driven from FLASH
rpicam-still --shutter 3000 --gain 4.0 -o part.jpg
```

**B. Multi-camera sync (two AR0234, one master clock)**

```ini
# both sensors:
dtoverlay=ar0234,cam0,4lane,sync-sink,flash
```
Feed the same `TRIG` to both; frames are timing-locked. Trigger period ≥ frame length.

**C. High-speed strobe, 960×600 @ 120 Hz (4-lane)**

```ini
dtoverlay=ar0234,cam0,4lane,external-trigger,flash
```
```bash
rpicam-vid -t 5000 --mode 960:600:10 --framerate 120 --shutter 2000 --gain 6.0 \
           --nopreview -o hs.h264
```

---

## 8. Verify & troubleshoot

```bash
cat /sys/module/ar0234/parameters/trigger_mode      # 1 or 2 when enabled
dmesg | grep -i ar0234
rpicam-hello --list-cameras
```

| Symptom | Likely cause |
|---|---|
| no frames under trigger | `TRIG` not at 1.8 V / no common ground / pulse too short (<125 ns) |
| exposure/brightness unstable | AGC on — pin `--shutter` and `--gain` |
| frame rate below trigger rate | exposure too long (violates §5 constraint) or above max trigger freq |
| strobe not firing | `flash` option missing, or FLASH not level-shifted to the illuminator |
| strobe mis-timed vs exposure | tune `flash-lead` / `flash-lag` |

---

## 9. Quick reference

```ini
# config.txt one-liners
dtoverlay=ar0234,cam0,4lane,external-trigger,flash              # pulsed + strobe (colour)
dtoverlay=ar0234,cam0,4lane,mono,external-trigger,flash         # pulsed + strobe (mono)
dtoverlay=ar0234,cam0,4lane,sync-sink,flash                     # multi-cam sync + strobe
dtoverlay=ar0234,cam0,4lane,external-trigger,flash,flash-lead=10
```
```bash
rpicam-hello -t 0 --shutter 10000 --gain 2.0                    # live, fixed exposure
rpicam-vid  -t 5000 --shutter 10000 --gain 2.0 --framerate 30 -o trig.h264
echo 1 | sudo tee /sys/module/ar0234/parameters/trigger_mode   # runtime enable
```
