#!/bin/bash
# apply-trigger-strobe.sh - switch an already-installed AR0234 to
# external-trigger + strobe(FLASH) by editing config.txt. No reboot.
#
#   sudo ./apply-trigger-strobe.sh              # colour, pulsed trigger + flash
#   MONO=1 sudo ./apply-trigger-strobe.sh       # mono module
#   MODE=sync-sink sudo ./apply-trigger-strobe.sh
#   LEAD=10 sudo ./apply-trigger-strobe.sh      # flash-lead=10 (~34us, 4-lane)
set -euo pipefail
[ "$EUID" -eq 0 ] || { echo "Run as root: sudo ./apply-trigger-strobe.sh"; exit 1; }

MODE="${MODE:-external-trigger}"          # external-trigger | sync-sink
BASE="cam0,4lane"
[ "${MONO:-0}" = "1" ] && BASE="$BASE,mono"
OPTS="$BASE,$MODE,flash"
[ -n "${LEAD:-}" ] && OPTS="$OPTS,flash-lead=$LEAD"
[ -n "${LAG:-}"  ] && OPTS="$OPTS,flash-lag=$LAG"

CFG=/boot/firmware/config.txt; [ -f "$CFG" ] || CFG=/boot/config.txt
TS="$(date +%Y%m%d-%H%M%S)"
cp "$CFG" "$CFG.bak.$TS"
sed -i '/^dtoverlay=ar0234/d;/^camera_auto_detect=/d' "$CFG"
{ echo ""; echo "# AR0234 external-trigger + strobe (applied $TS)";
  echo "camera_auto_detect=0"; echo "dtoverlay=ar0234,$OPTS"; } >> "$CFG"

echo "config.txt updated (backup: $CFG.bak.$TS):"
echo "  dtoverlay=ar0234,$OPTS"
echo ""
echo "Reboot to apply:  sudo reboot"
echo "Then wire a 1.8V pulse to TRIG and capture with fixed shutter/gain (see MANUAL.md)."
