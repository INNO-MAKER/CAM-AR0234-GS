#!/bin/bash
# Remove the files this package installed under /usr/local.
set -euo pipefail
[ "$EUID" -eq 0 ] || { echo "Please run as root (sudo)"; exit 1; }
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PREFIX=/usr/local
echo "Removing files listed in the payload from $PREFIX ..."
tar -tzf "$SCRIPT_DIR/usr-local-payload.tar.gz" | sort -r | while read -r f; do
    p="$PREFIX/$f"
    if   [ -L "$p" ] || [ -f "$p" ]; then rm -f "$p"
    elif [ -d "$p" ]; then rmdir "$p" 2>/dev/null || true
    fi
done
ldconfig
echo "Done. Restore a previous install from $PREFIX/.rpicam-runtime-backup-* if needed."
