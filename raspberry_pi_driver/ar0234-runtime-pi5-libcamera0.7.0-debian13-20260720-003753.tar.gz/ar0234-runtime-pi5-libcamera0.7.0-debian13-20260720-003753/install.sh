#!/bin/bash
# libcamera runtime installer (ar0234).
# Installs the complete stack under /usr/local. Never touches /usr/lib, so the
# distro libcamera keeps working alongside it.
set -euo pipefail
[ "$EUID" -eq 0 ] || { echo "Please run as root (sudo)"; exit 1; }
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TS="$(date +%Y%m%d-%H%M%S)"
PREFIX=/usr/local
TRIPLET="aarch64-linux-gnu"
LC_VER="0.7.0"
SENSORS="ar0234"
LIBDIR="lib/$TRIPLET"

HOST_TRIPLET="$(gcc -dumpmachine 2>/dev/null || echo unknown)"
if [ "$HOST_TRIPLET" != "unknown" ] && [ "$HOST_TRIPLET" != "$TRIPLET" ]; then
    echo "ERROR: package is for '$TRIPLET' but this system is '$HOST_TRIPLET'."
    exit 1
fi

echo "=== libcamera runtime installer ==="
echo "  Prefix:    $PREFIX"
echo "  libcamera: $LC_VER"
echo "  Sensors:   ${SENSORS:-<unspecified>}"
echo ""

echo "[1/5] Checking C/C++ runtime..."
# No `head` inside the pipeline: it exits early, ldd takes SIGPIPE, and pipefail
# then fires the `|| echo '?'` fallback even though grep already printed the value.
GLIBC_VER="$(ldd --version 2>/dev/null | sed -n '1s/.*[^0-9]\([0-9]\+\.[0-9]\+\)$/\1/p' || true)"
echo "      host glibc: ${GLIBC_VER:-unknown}"
if [ "$(strings -a /usr/lib/"$TRIPLET"/libstdc++.so.6 2>/dev/null | grep -c GLIBCXX_3.4.32 || true)" -eq 0 ]; then
    echo "      WARNING: host libstdc++ looks older than the build host's."
    echo "               If rpicam-hello fails with 'GLIBCXX_... not found',"
    echo "               rebuild from the source package on this machine."
fi

echo "[2/5] Backing up any existing $PREFIX libcamera..."
BACKED=0
for p in "$PREFIX/$LIBDIR/libcamera.so."* "$PREFIX/$LIBDIR/libcamera" \
         "$PREFIX/share/libcamera" "$PREFIX/libexec/libcamera"; do
    [ -e "$p" ] || continue
    if [ $BACKED -eq 0 ]; then
        BAK="$PREFIX/.rpicam-runtime-backup-$TS"; mkdir -p "$BAK"; BACKED=1
        echo "      backup dir: $BAK"
    fi
    cp -a "$p" "$BAK/" 2>/dev/null || true
done
[ $BACKED -eq 0 ] && echo "      (nothing pre-existing)"

echo "[3/5] Unpacking into $PREFIX..."
tar -xzf "$SCRIPT_DIR/usr-local-payload.tar.gz" -C "$PREFIX"
ldconfig
echo "      done"

echo "[4/5] Verifying dynamic linkage..."
FAIL=0
BIN="$PREFIX/bin/rpicam-hello"
if [ ! -x "$BIN" ]; then echo "      ERROR: $BIN missing"; FAIL=1; else
    if [ "$(ldd "$BIN" 2>/dev/null | grep -c 'not found' || true)" -gt 0 ]; then
        echo "      ERROR: unresolved libraries:"
        ldd "$BIN" | grep "not found" | sed 's/^/        /'
        FAIL=1
    fi
    # Our libs must win over any distro copy with a colliding SONAME (libpisp!).
    for lib in libcamera.so libcamera-base.so libpisp.so librpicam_app.so; do
        RES="$(ldd "$BIN" 2>/dev/null | grep -oE "/[^ ]*/${lib}[^ ]*" | head -1 || true)"
        [ -z "$RES" ] && continue
        case "$RES" in
            "$PREFIX"/*) echo "      OK  $lib -> $RES";;
            *) echo "      ERROR: $lib resolved to $RES (expected under $PREFIX)"; FAIL=1;;
        esac
    done
fi
IPA="$(ls "$PREFIX/$LIBDIR"/libcamera/ipa/ipa_rpi_*.so 2>/dev/null | head -1 || true)"
if [ -n "$IPA" ]; then
    [ -f "$IPA.sign" ] && echo "      OK  IPA signed: $(basename "$IPA")" \
                       || echo "      WARN: $(basename "$IPA") unsigned -- will run isolated"
fi
[ $FAIL -eq 1 ] && { echo ""; echo "Verification FAILED. See errors above."; exit 1; }

echo "[5/5] Checking PATH precedence..."
WHICH="$(command -v rpicam-hello || true)"
if [ "$WHICH" != "$PREFIX/bin/rpicam-hello" ]; then
    echo "      WARNING: 'rpicam-hello' resolves to '$WHICH'."
    echo "               Ensure $PREFIX/bin precedes /usr/bin in PATH, or call"
    echo "               $PREFIX/bin/rpicam-hello explicitly."
else
    echo "      OK  $WHICH"
fi

echo ""
echo "Runtime installed. The distro libcamera in /usr/lib was NOT modified."
echo ""
echo "Verify:  rpicam-hello --list-cameras"
echo "         (needs the kernel driver too -- see the *-driver-*.tar.gz package)"
