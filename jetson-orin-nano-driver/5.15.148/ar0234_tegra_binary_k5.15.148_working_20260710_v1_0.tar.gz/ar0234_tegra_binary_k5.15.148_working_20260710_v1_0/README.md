# AR0234CS - Jetson Orin Nano driver (BINARY package)

Prebuilt onsemi AR0234CS 2.3MP global-shutter camera driver for Jetson Orin Nano
(p3768 + p3767, L4T r36.4.x / JetPack 6, kernel 5.15.148-tegra). 1920x1200 @ up to
60 fps, 2-lane MIPI, mono or color via device tree.

## Layout
- `binary/`   prebuilt kernel module (ar0234.ko)
- `overlays/` device-tree overlays: A / C / dual / dual-mono
- `scripts/`  preview / capture / ISP helpers
- `isp/`      Argus ISP overrides

## Connector mapping (p3768)
- **A overlay** = silkscreen **CAM0**
- **C overlay** = silkscreen **CAM1**
- **dual** = both

## Install
    sudo ./install_binary.sh
Then activate an overlay with jetson-io (the installer prints the command) and reboot.
See USER_MANUAL.md.
