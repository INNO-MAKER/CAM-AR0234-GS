#!/usr/bin/env bash
# Install the prebuilt AR0234 driver on a Jetson Orin Nano (L4T r36.4.x, kernel
# 5.15.148-tegra): module + overlays (A/C/dual/dual-mono) + ISP, then reload.
# Overlay activation is jetson-io ONLY. NEVER edits extlinux; NEVER reboots.
set -euo pipefail
PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MODDIR="/lib/modules/$(uname -r)/kernel/drivers/media/i2c"
ISP="camera_overrides.ar0234_starter.isp"
OVL=(tegra234-ar0234-A tegra234-ar0234-C tegra234-ar0234-dual tegra234-ar0234-dual-mono)
EXPECT="5.15.148-tegra"
[ "$(uname -r)" = "${EXPECT}" ] || echo "WARNING: module built for ${EXPECT}, running $(uname -r); use source package if modprobe fails."

echo "=== module ==="
sudo install -D -m 0644 "${PKG}/binary/ar0234.ko" "${MODDIR}/ar0234.ko"; sudo depmod -a
echo "=== overlays ==="
for n in "${OVL[@]}"; do sudo install -m 0644 "${PKG}/overlays/${n}.dtbo" "/boot/${n}.dtbo"; done
# stamp this machine's CSI header name so jetson-io always lists the overlays
HDR="$(sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -l 2>/dev/null | grep -oE 'Jetson [0-9]+pin CSI Connector' | head -1 || true)"
if [ -n "${HDR}" ] && command -v fdtput >/dev/null 2>&1; then
	for n in "${OVL[@]}"; do sudo fdtput -t s "/boot/${n}.dtbo" / jetson-header-name "${HDR}" || true; done
fi
echo "=== ISP ==="
sudo mkdir -p /var/nvidia/nvcam/settings
sudo install -m 0644 "${PKG}/isp/${ISP}" "/var/nvidia/nvcam/settings/camera_overrides.isp" || true
echo "=== reload ==="
sudo modprobe -r ar0234 2>/dev/null || true; sudo modprobe ar0234 2>/dev/null || true
sudo systemctl restart nvargus-daemon 2>/dev/null || true
echo "Done. Activate an overlay then reboot:"
echo "  sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -n 2=\"Camera AR0234 A (i2c@0)\""
