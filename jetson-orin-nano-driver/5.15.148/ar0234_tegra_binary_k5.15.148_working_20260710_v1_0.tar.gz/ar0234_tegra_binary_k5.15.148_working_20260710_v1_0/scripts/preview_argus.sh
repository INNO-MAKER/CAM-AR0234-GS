#!/usr/bin/env bash
# AR0234 color live preview via Argus (nvarguscamerasrc -> ISP -> display).
# AR0234CS global shutter, single 1920x1200 mode (2-lane, ~60 fps). Use this for
# the COLOR variant; for a MONO module use preview_argus_mono.sh (forces GRAY8),
# and for raw/no-ISP debugging use preview_mono.sh.
#
# Usage:  ./preview_argus.sh [duration_seconds]
#   duration_seconds : 0 (default) = continuous; >0 = stop after N seconds.
# Env:
#   SENSOR_ID    : 0 (A/cam0 rail) or 1 (C/cam1 rail); default 0 (dual overlay only).
#   FRAMERATE    : gstreamer framerate fraction; default 60/1.
#   PREVIEW_SINK : override the auto-selected video sink.
set -euo pipefail

DURATION="${1:-0}"
SENSOR_ID="${SENSOR_ID:-0}"
FRAMERATE="${FRAMERATE:-60/1}"
FPS_NUM="${FRAMERATE%%/*}"
FPS_DEN="${FRAMERATE##*/}"
PREVIEW_SINK="${PREVIEW_SINK:-}"
SENSOR_MODE=0
OUT_W=1920
OUT_H=1200

if ! [[ "${DURATION}" =~ ^[0-9]+$ ]]; then
	echo "duration_seconds must be a non-negative integer; use 0 for continuous preview" >&2
	exit 2
fi

if [ -z "${PREVIEW_SINK}" ]; then
	if gst-inspect-1.0 nv3dsink >/dev/null 2>&1; then
		PREVIEW_SINK="nv3dsink"
	elif gst-inspect-1.0 nveglglessink >/dev/null 2>&1; then
		PREVIEW_SINK="nveglglessink"
	else
		PREVIEW_SINK="autovideosink"
	fi
fi

NUM_BUFFERS_ARG=()
if [ "${DURATION}" -gt 0 ]; then
	NUM_BUFFERS=$(((DURATION * FPS_NUM + FPS_DEN - 1) / FPS_DEN))
	NUM_BUFFERS_ARG=(num-buffers="${NUM_BUFFERS}")
fi

echo "Preview (COLOR) sensor-id=${SENSOR_ID} ${OUT_W}x${OUT_H} framerate=${FRAMERATE} sink=${PREVIEW_SINK}"

case "${PREVIEW_SINK}" in
	autovideosink|xvimagesink|ximagesink)
		gst-launch-1.0 -e \
			nvarguscamerasrc sensor-id="${SENSOR_ID}" "${NUM_BUFFERS_ARG[@]}" \
				sensor-mode="${SENSOR_MODE}" \
			! "video/x-raw(memory:NVMM),width=${OUT_W},height=${OUT_H},format=NV12,framerate=${FRAMERATE}" \
			! nvvidconv \
			! "video/x-raw,format=I420,width=${OUT_W},height=${OUT_H},framerate=${FRAMERATE}" \
			! videoconvert \
			! fpsdisplaysink video-sink="${PREVIEW_SINK}" text-overlay=false sync=false fps-update-interval=1000
		;;
	*)
		gst-launch-1.0 -e \
			nvarguscamerasrc sensor-id="${SENSOR_ID}" "${NUM_BUFFERS_ARG[@]}" \
				sensor-mode="${SENSOR_MODE}" \
			! "video/x-raw(memory:NVMM),width=${OUT_W},height=${OUT_H},format=NV12,framerate=${FRAMERATE}" \
			! fpsdisplaysink video-sink="${PREVIEW_SINK}" text-overlay=false sync=false fps-update-interval=1000
		;;
esac
