#!/usr/bin/env bash
# Install the AR0234 STARTER ISP override (neutral bring-up baseline, not
# production tuning). Use this as the starting point for color-cast / mono ISP
# tuning (see skill Phase 5b). Thin wrapper over install_isp.sh; same backup +
# rollback path. NEVER reboots.
#
# Usage:  ./install_starter_isp.sh
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "Installing the NEUTRAL STARTER ISP (camera_overrides.ar0234_starter.isp)."
echo "For the vendor tuned override use ./install_isp.sh instead."
ISP_FILE="camera_overrides.ar0234_starter.isp" exec "${SCRIPT_DIR}/install_isp.sh"
