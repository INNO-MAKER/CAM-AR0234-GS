#!/usr/bin/env bash
# Roll back the AR0234 ISP override installed by install_isp.sh /
# install_starter_isp.sh: restore the recorded backup, or remove the override if
# none existed before. Restarts nvargus-daemon; NEVER reboots.
set -euo pipefail

SETTINGS_DIR="/var/nvidia/nvcam/settings"
DST="${SETTINGS_DIR}/camera_overrides.isp"
BACKUP_DIR="${SETTINGS_DIR}/backup_ar0234_isp"
STATE_FILE="${BACKUP_DIR}/last_install_state"
BACKUP_FILE=""

if [ -f "$STATE_FILE" ]; then
	# shellcheck disable=SC1090
	. "$STATE_FILE"
	BACKUP_FILE="${backup:-}"
fi

if [ -n "$BACKUP_FILE" ] && [ -f "$BACKUP_FILE" ]; then
	echo "Restoring previous ISP override:"
	echo "  ${BACKUP_FILE}"
	sudo install -m 0644 "$BACKUP_FILE" "$DST"
else
	if [ -f "$DST" ]; then
		echo "No previous ISP backup recorded. Removing installed override:"
		echo "  ${DST}"
		sudo rm -f "$DST"
	else
		echo "No installed ISP override found."
	fi
fi

echo "Restarting nvargus-daemon"
sudo systemctl restart nvargus-daemon || true
echo "Done"
