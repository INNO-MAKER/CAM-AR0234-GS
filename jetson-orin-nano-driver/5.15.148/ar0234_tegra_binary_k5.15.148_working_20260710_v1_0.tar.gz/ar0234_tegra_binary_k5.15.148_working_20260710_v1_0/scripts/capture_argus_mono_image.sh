#!/bin/bash
# Capture a MONO still via Argus. Argus does demosaic/AE, then the pipeline
# forces GRAY8 to keep luma only (mono sensor through the color ISP path).
# For the mono AR0234 module (also gives clean grayscale from a color one).
# Usage: ./capture_argus_mono_image.sh [output.jpg|output.png]
set -e
OUT="${1:-/tmp/ar0234_argus_mono.jpg}"
SENSOR_ID="${SENSOR_ID:-0}"
W="${W:-1920}"
H="${H:-1200}"
FRAMERATE="${FRAMERATE:-60/1}"
NUM_BUFFERS="${NUM_BUFFERS:-30}"   # skip AE warm-up frames, keep the last
EXT="${OUT##*.}"
case "$EXT" in
  jpg|jpeg) ENC="jpegenc" ;;
  png)      ENC="pngenc" ;;
  *) echo "Unsupported extension .$EXT (use .jpg or .png)" >&2; exit 2 ;;
esac

echo "AR0234 MONO capture ${W}x${H} -> $OUT (GRAY8, luma only)"
gst-launch-1.0 -e \
  nvarguscamerasrc sensor-id="$SENSOR_ID" sensor-mode=0 num-buffers="$NUM_BUFFERS" \
  ! "video/x-raw(memory:NVMM),width=${W},height=${H},format=NV12,framerate=${FRAMERATE}" \
  ! nvvidconv \
  ! "video/x-raw,format=GRAY8,width=${W},height=${H}" \
  ! videoconvert \
  ! "$ENC" \
  ! multifilesink location="$OUT" max-files=1
echo "saved: $OUT"
