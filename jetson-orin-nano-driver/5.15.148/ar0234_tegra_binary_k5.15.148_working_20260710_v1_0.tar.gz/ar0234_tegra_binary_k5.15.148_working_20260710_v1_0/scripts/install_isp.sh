#!/usr/bin/env bash
# Install an AR0234 Argus ISP override into the live nvcam settings, with backup
# so it can be rolled back. Restarts nvargus-daemon; NEVER reboots.
#
# Default installs the vendor tuned override (camera_overrides.ar0234.isp).
# For the neutral tuning baseline use install_starter_isp.sh (which calls this
# with ISP_FILE=camera_overrides.ar0234_starter.isp).
#
# Usage:  ./install_isp.sh
# Env:    ISP_FILE=<file under isp/>   (default camera_overrides.ar0234.isp)
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PACKAGE_DIR="$(dirname "$SCRIPT_DIR")"
ISP_FILE="${ISP_FILE:-camera_overrides.ar0234.isp}"
SRC="${PACKAGE_DIR}/isp/${ISP_FILE}"
SETTINGS_DIR="/var/nvidia/nvcam/settings"
DST="${SETTINGS_DIR}/camera_overrides.isp"
BACKUP_DIR="${SETTINGS_DIR}/backup_ar0234_isp"
STATE_FILE="${BACKUP_DIR}/last_install_state"
STAMP="$(date +%Y%m%d_%H%M%S)"

if [ ! -s "$SRC" ]; then
	echo "ERROR: missing or empty ISP override: ${SRC}" >&2
	exit 1
fi

echo "Installing AR0234 ISP override: ${ISP_FILE}"
sudo mkdir -p "$SETTINGS_DIR" "$BACKUP_DIR"

if [ -f "$DST" ]; then
	BACKUP_FILE="${BACKUP_DIR}/camera_overrides.isp.${STAMP}.bak"
	sudo cp "$DST" "$BACKUP_FILE"
	printf "backup=%s\n" "$BACKUP_FILE" | sudo tee "$STATE_FILE" >/dev/null
	echo "Backed up existing override to: ${BACKUP_FILE}"
else
	printf "backup=\n" | sudo tee "$STATE_FILE" >/dev/null
	echo "No existing override found. Rollback will remove the installed file."
fi

sudo install -m 0644 "$SRC" "$DST"
echo "Restarting nvargus-daemon"
sudo systemctl restart nvargus-daemon || true
echo "Installed: ${DST}"
echo "Rollback:  ./rollback_isp.sh"
