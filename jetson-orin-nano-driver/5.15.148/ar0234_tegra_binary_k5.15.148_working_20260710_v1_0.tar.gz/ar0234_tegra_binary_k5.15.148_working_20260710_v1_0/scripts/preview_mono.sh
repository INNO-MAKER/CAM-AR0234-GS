#!/usr/bin/env bash
# AR0234 raw V4L2 mono capture/preview - INTERNAL DEBUG TOOL.
#
# This is the honest raw path: it bypasses Argus + the ISP entirely and captures
# straight off VI, so it surfaces VI/CSI faults as HARD errors (dmesg corr_err)
# instead of hiding them as visible tearing. It is the fastest early-bring-up
# probe (mono luma is honest, no debayer/AWB), 
#
# It encodes the hard-won rules that stop raw V4L2 from hanging (see the global
# skill's "Debug playbook"):
#   1. STOP nvargus-daemon first  - else it owns the sensor and raw blocks forever
#   2. bypass_mode=0              - else VI passes buffers through without capturing
#   3. override_enable=1          - else manual exposure/gain are ignored
#   4. timeout + EXIT restore trap - a killed raw stream wedges the VI bypass
#      channel; the trap reloads the module + nvargus so the next capture is clean
#
# Usage:  ./preview_mono.sh [frames] [out_prefix]
#   frames     : number of frames to capture (default 5; use a few for motion)
#   out_prefix : output path prefix (default /tmp/ar0234_mono)
# Env:
#   DEVICE=/dev/video0  EXPOSURE=8000  GAIN=40  FRAME_RATE=60000000
#   SENSOR=ar0234       KEEP_RAW=0 (1 = keep the .raw alongside the .png)
set -uo pipefail

DEVICE="${DEVICE:-/dev/video0}"
W=1920; H=1200
FRAMES="${1:-5}"
PREFIX="${2:-/tmp/ar0234_mono}"
EXPOSURE="${EXPOSURE:-8000}"
GAIN="${GAIN:-40}"
FRAME_RATE="${FRAME_RATE:-60000000}"
SENSOR="${SENSOR:-ar0234}"
KEEP_RAW="${KEEP_RAW:-0}"
RAW="${PREFIX}.raw"
SUDO() { echo jetsonbot | sudo -S bash -c "$*" 2>/dev/null; }

RESTORE_DONE=0
restore() {
  [ "$RESTORE_DONE" = 1 ] && return; RESTORE_DONE=1
  echo "Restoring camera (reload ${SENSOR} + nvargus)..." >&2
  SUDO "systemctl stop nvargus-daemon; rmmod ${SENSOR} 2>/dev/null; sleep 1; modprobe ${SENSOR} 2>/dev/null; systemctl start nvargus-daemon"
}
trap restore EXIT INT TERM

echo "Stopping nvargus-daemon for V4L2 access..." >&2
SUDO "systemctl stop nvargus-daemon"; sleep 1

echo "Capturing ${FRAMES} raw frame(s) ${W}x${H} BA10 (RAW10) from ${DEVICE}..."
v4l2-ctl -d "${DEVICE}" \
  --set-ctrl="bypass_mode=0,override_enable=1,exposure=${EXPOSURE},gain=${GAIN},frame_rate=${FRAME_RATE}" \
  --set-fmt-video="width=${W},height=${H},pixelformat=BA10" \
  --stream-mmap=4 --stream-skip=3 --stream-count="${FRAMES}" --stream-to="${RAW}" 2>&1 &
CAP_PID=$!
# hard cap so a wedged VI can't hang the shell; the trap restores either way.
( sleep 20; kill "${CAP_PID}" 2>/dev/null ) & WD=$!
wait "${CAP_PID}" 2>/dev/null; RC=$?
kill "${WD}" 2>/dev/null

SZ=$(stat -c%s "${RAW}" 2>/dev/null || echo 0)
FRAME_BYTES=$((W*H*2))
echo "captured ${SZ} bytes (expect ${FRAMES} x ${FRAME_BYTES} = $((FRAMES*FRAME_BYTES)))"
if [ "${SZ}" -lt "${FRAME_BYTES}" ]; then
  echo "ERROR: no full frame. If 0 bytes: check nvargus stopped / check dmesg for capture errors" >&2
  echo "       (if 0 bytes persists, reload the driver and retry)." >&2
  exit 1
fi

# Convert each RAW10 frame (16-bit LE container, low 10 bits) to an 8-bit PGM to view.
python3 - "${RAW}" "${PREFIX}" "${W}" "${H}" "${FRAME_BYTES}" <<'PY'
import sys, numpy as np
raw, prefix, W, H, fb = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5])
data = open(raw, 'rb').read()
n = len(data)//fb
for i in range(n):
    a = np.frombuffer(data[i*fb:(i+1)*fb], dtype='<u2').reshape(H, W) & 0x3ff
    lo, hi = np.percentile(a, 1), np.percentile(a, 99)
    hi = max(hi, lo+1)
    img = np.clip((a.astype(np.float32)-lo)*255.0/(hi-lo), 0, 255).astype(np.uint8)
    out = f"{prefix}_{i:03d}.pgm"
    with open(out, 'wb') as f:
        f.write(b"P5\n%d %d\n255\n" % (W, H)); f.write(img.tobytes())
    print(f"  {out}  min={int(a.min())} max={int(a.max())} mean={a.mean():.1f}")
print(f"wrote {n} PGM frame(s). View: eog {prefix}_000.pgm  (or convert: pnmtopng)")
PY

[ "${KEEP_RAW}" = "1" ] || rm -f "${RAW}"
# camera restored by the EXIT trap
