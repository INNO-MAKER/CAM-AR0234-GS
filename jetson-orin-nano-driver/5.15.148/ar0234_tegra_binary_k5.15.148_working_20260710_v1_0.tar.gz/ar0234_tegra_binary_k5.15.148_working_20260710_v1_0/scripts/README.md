# AR0234 scripts

- `preview_argus.sh [sec]`        color live preview.
- `preview_argus_mono.sh [sec]`   grayscale (mono) live preview.
- `preview_mono.sh [frames]`      raw mono capture to PGM images.
- `capture_argus_mono_image.sh`   single mono JPEG.
- `install_isp.sh` / `install_starter_isp.sh` / `rollback_isp.sh`  ISP override management.

Env for previews: SENSOR_ID (0/1), FRAMERATE, PREVIEW_SINK, EXPOSURE, GAIN.
