# AR0234CS Jetson - User Manual (binary package)

## 1. Install
    sudo ./install_binary.sh
Installs the module, overlays, and ISP; reloads the driver. Does NOT reboot.

## 2. Activate an overlay (jetson-io)
    sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -l
    sudo python3 /opt/nvidia/jetson-io/config-by-hardware.py -n 2="Camera AR0234 A (i2c@0)"
Options: "Camera AR0234 A (i2c@0)" = silk CAM0, "... C (i2c@1)" = silk CAM1,
"... Dual (CAM0+CAM1)", or the mono dual. Reboot to apply.

## 3. Preview / capture
    cd scripts
    ./preview_argus.sh                 # color live preview
    ./preview_argus_mono.sh            # mono (grayscale)
    EXPOSURE=120 GAIN=13 ./preview_mono.sh 5   # raw mono frames -> PGM
    ./capture_argus_mono_image.sh      # single mono JPEG

## 4. ISP
    ./scripts/install_isp.sh           # vendor tuned override
    ./scripts/install_starter_isp.sh   # neutral baseline
    ./scripts/rollback_isp.sh          # restore previous

## 5. Verify
    ls /dev/video*
    dmesg | grep -i ar0234             # "detected ar0234 sensor" / chip id 0xa56

## Notes
- Bring up on `dual` first, then narrow to A/C.
- If a prebuilt module fails with "version magic", use the source package.
